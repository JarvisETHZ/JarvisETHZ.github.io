%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples.
% Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme.
% Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/9deec80b-9112-4a54-87ab-6a68c95a6846
% Set the options for data generation
opt_gen = daline.setopt('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200, 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'data.curvePlot', 0);

% Generate the data
data = daline.generate(opt_gen);

% Set the options for Least Squares with Huber Weighting Function and visualization
opt_fit = daline.setopt('method.name', 'LS_HBW', 'variable.predictor', {'P', 'Q'}, 'variable.response', {'PF', 'Vm'}, 'HBW.TuningConst', [1:0.1:1.4], 'HBW.PCA', 1, 'PLOT.theme', 'academic', 'PLOT.style', 'dark', 'PLOT.switch', 0);

% Train the model and visualize results
model = daline.fit(data, opt_fit);

%% MATLAB:
% The above code ran successfully

%% Hidden Mistake:
% daline.fit cannot plot figures