%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples.
% Rank the accuracy of LS and QR Decomposition for 'case14'.
% Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods.
% Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously.
% Finally, disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/4bcd650e-676d-4b1b-9eff-efbd062d90ce
% Generate the training and testing data
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200, 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'data.curvePlot', 0);
data = daline.data(opt);

% Set options for the methods
optLS = daline.setopt('method.name', 'LS', 'variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF'}, 'PLOT.switch', 0);
optQR = daline.setopt('method.name', 'QR', 'variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF'}, 'PLOT.switch', 0);

% Rank the accuracy of LS and QR methods
accuracyLS = daline.fit(data, optLS);
accuracyQR = daline.fit(data, optQR);

% Compare accuracy
fprintf('Accuracy of LS method: %f\n', accuracyLS.Accuracy);
fprintf('Accuracy of QR method: %f\n', accuracyQR.Accuracy);

% Disable the plotting
opt.PLOT.switch = 0;

% Rank and compare the accuracy
accuracyRank = daline.rank(data, {'LS', 'QR'}, opt);
disp('Ranked accuracy of LS and QR methods:');
disp(accuracyRank);
