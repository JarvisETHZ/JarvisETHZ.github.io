
%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples.
% Visualize the linearization results of Partial Least Squares with Clustering with a light style and an academic theme.
% Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/b22bf3ef-5909-4ed9-ac9b-eebc1c01c5e9
% Set options for data generation
opt_data = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'data.curvePlot', 0);

% Generate the data
data = daline.generate(opt_data);

% Set options for visualization
opt_viz = daline.setopt('PLOT.style', 'light', 'PLOT.theme', 'academic', 'PLOT.switch', 0);

% Define methods for visualization
methods = {'PLS_CLS'};

% Visualize the linearization results
daline.time(data, methods, opt_viz);

%% MATLAB:
% The above code ran successfully


%% Hidden Mistake: 
% daline.time cannot visualize the linearization result