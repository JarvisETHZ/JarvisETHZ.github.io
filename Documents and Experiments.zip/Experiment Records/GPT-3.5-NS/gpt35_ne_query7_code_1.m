%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Introduce outliers into the data with an outlier percentage of 5% and a factor of 2.

%% Code Writen by LLM:
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);
data = daline.generate(opt);
data = daline.outlier(data, 'outlier.percentage', 5, 'outlier.factor', 2);

%% MATLAB:
% The above code ran successfully