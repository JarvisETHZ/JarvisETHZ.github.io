%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);
data = daline.generate(opt);

opt_plot = daline.setopt('plot.theme', 'academic', 'plot.style', 'dark', 'plot.enable', 0);
model = daline.fit(data, 'method.name', 'LS_HBW');
daline.plot(model, opt_plot);