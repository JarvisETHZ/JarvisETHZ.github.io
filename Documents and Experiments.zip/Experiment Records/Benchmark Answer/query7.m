%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. 
% Introduce outliers into the data with an outlier percentage of 5% and a factor of 2.

%% Code Written by LLM:
% Setting up the options for data generation and outlier introduction
opt = daline.setopt('case.name', 'case14', ...           % Specify the case name
                    'num.trainSample', 300, ...          % Number of training samples
                    'num.testSample', 200, ...           % Number of testing samples
                    'outlier.switchTrain', 1, ...        % Add outliers to training data
                    'outlier.switchTest', 1, ...         % Add outliers to testing data
                    'outlier.percentage', 5, ...         % Percentage of outliers
                    'outlier.factor', 2);                % Factor for outliers

% Generating the data with the specified options
data = daline.data(opt);

%% MATLAB:
% The above code ran successfully