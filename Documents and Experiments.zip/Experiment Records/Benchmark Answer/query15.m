%% Prompt:
% Generate data for 'case14' with 200 training samples and 150 testing samples. Train and test a model using RR_KPC, while set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'}.

%% Code Writen by LLM:
% Generate data
data = daline.data('case.name', 'case14', 'num.trainSample', 200, 'num.testSample', 150);

% Train and test the model using RR_KPC
model = daline.fit(data, 'method.name', 'RR_KPC', 'variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF', 'QF'});

%% MATLAB:
% The above code ran successfully