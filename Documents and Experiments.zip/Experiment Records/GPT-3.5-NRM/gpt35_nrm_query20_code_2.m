%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
data = daline.data('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);
models = daline.rank(data, {'DLPF_C', 'PTDF'});

%% MATLAB:
% The above code ran successfully