%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
data = daline.data('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);
model = daline.fit(data, 'method.name', 'LS_HBW');
opt = daline.setopt('PLOT.style', 'dark', 'PLOT.theme', 'academic', 'PLOT.switch', 0);
daline.plot(model, opt);

%% MATLAB:
% The above code ran successfully