%% Prompt:
% Generate data for 'case9' with 200 training samples and 150 testing samples, where you should use the type 'TimeSeriesRand' for data generation, turn on the noise adding mode for the training dataset, and add noise to the training dataset with a signal-to-noise ratio of 45 dB. Then, compare and rank the computing efficiency of methods LS_LIFX and RR_KPC. Set the number of clusters as 3 for RR_KPC. Use 5 repetitions for plotting. Finally, use the dark style for plotting, but disable the plotting. 

%% Code Writen by LLM:
data = daline.data('case.name', 'case9', 'num.trainSample', 200, 'num.testSample', 150, 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'noise.switchTrain', 1, 'noise.SNR_dB', 45);

opt = daline.setopt('LS.clusNumInterval', 3, 'PLOT.repeat', 5, 'PLOT.style', 'dark', 'PLOT.switch', 0);
timing = daline.time(data, {'LS', 'RR_KPC'}, opt);