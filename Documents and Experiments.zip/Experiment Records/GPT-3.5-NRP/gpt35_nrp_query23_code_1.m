%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Visualize the linearization results of Partial Least Squares with Clustering with a light style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
data = daline.data('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);
model = daline.fit(data, 'method.name', 'PLS_CLS', 'PLOT.style', 'light', 'PLOT.theme', 'academic', 'PLOT.switch', 0);

%% MATLAB:
% The above code ran successfully

%% Hidden Mistake:
% daline.fit doesn't not support plotting parameters