%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
[data_train, data_test] = daline.generate('case14', 300, 200);


model = daline.fit(data_train, 'LS_HBL', data_test);
daline.plot(model, 'dark', 'academic', 'off');