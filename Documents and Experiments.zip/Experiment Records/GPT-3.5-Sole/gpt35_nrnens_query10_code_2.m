%% Prompt:
% Generate data for 'case57' with 600 training samples and 300 testing samples. Add noise to the training data with a SNR of 45dB. Then Filter out noise from the training dataset.

%% Code Writen by LLM:
% Generate data for 'case57' with 600 training samples and 300 testing samples
[dataTrain, dataTest] = daline.generate('case57', 600, 300);

% Add noise to the training data with a SNR of 45dB
dataTrainNoisy = daline.noise(dataTrain, 'SNR', 45);

% Filter out noise from the training dataset
dataTrainFiltered = daline.deoutlier(dataTrainNoisy);