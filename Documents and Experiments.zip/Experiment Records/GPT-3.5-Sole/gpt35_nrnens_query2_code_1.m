%% Prompt:
% Please write the code to create data for 'case39' with 500 training samples and 300 testing samples, and add noise with a signal-to-noise ratio of 45 dB.

%% Code Writen by LLM:
% Generate data for 'case39' with 500 training samples and 300 testing samples
[dataTrain, dataTest] = daline.generate('case39', 500, 300);

% Add noise with a signal-to-noise ratio of 45 dB
dataTrain = daline.noise(dataTrain, 'SNR', 45);
dataTest = daline.noise(dataTest, 'SNR', 45);