%% Prompt:
% Please write the code to manage a complete cycle for 'case39' using the method COD. Set the data base type to 'Random' and the number of training samples to 300. Disable the plotting.

%% Code Writen by LLM:
[data_train, data_test, model] = daline.all('case39', 'COD', 'Random', 300, 'off');