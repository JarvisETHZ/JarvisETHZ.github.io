%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Introduce outliers into the data with an outlier percentage of 5% and a factor of 2.

%% Code Writen by LLM:
[dataTrain, dataTest] = daline.data('case14', 300, 200, 'OUT.outlierPercentage', 0.05, 'OUT.factor', 2);