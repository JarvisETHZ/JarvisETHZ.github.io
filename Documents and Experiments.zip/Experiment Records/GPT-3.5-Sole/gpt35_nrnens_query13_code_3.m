%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Filter out outliers from the training and testing datasets using the 'grubbs' method. Set the tolerance level for outlier detection as 0.7.

%% Code Writen by LLM:
options = struct('outlier', struct('GRU', struct('tolerance', 0.7)));
[dataTrain, dataTest] = daline.data('case14', 400, 200, options);