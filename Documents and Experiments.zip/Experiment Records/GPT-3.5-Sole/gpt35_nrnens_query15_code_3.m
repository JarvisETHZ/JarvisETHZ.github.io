%% Prompt:
% Generate data for 'case14' with 200 training samples and 150 testing samples. Train and test a model using RR_KPC, while set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'}.

%% Code Writen by LLM:
% Data Generation
data = daline.generate('case14', 200, 150);

% Model Training
model = daline.fit(data.train, data.test, 'RR_KPC', {'P', 'Vm2'}, {'PF', 'QF'});