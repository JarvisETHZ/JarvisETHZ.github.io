%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Rank the accuracy of LS and QR Decomposition for 'case14'. Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods. Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously. Finally, disable the plotting. 

%% Code Writen by LLM:
% Generate data for 'case14' with 300 training samples and 200 testing samples
[dataTrain, dataTest] = daline.generate('case14', 300, 200);

% Rank the accuracy of LS and QR Decomposition for 'case14'
results = daline.rank(dataTrain, dataTest, {'LS', 'QR'}, {'P', 'Vm2'}, {'PF'}, 'plot', false);