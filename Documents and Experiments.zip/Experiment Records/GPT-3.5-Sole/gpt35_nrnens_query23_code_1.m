%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Visualize the linearization results of Partial Least Squares with Clustering with a light style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
[dataTrain, dataTest] = daline.generate('case14', 400, 200);
model = daline.fit(dataTrain, dataTest, 'PLS_CLU');
daline.plot(model, 'light', 'academic', 'off');