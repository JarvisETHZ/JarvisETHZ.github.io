%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Generate data for 'case14' with 400 training samples and 200 testing samples
data = daline.generate('case14', 400, 200);

% Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'
results = daline.rank(data, {'Decoupled Linearized Power Flow with Data-driven Correction', 'Power Transfer Distribution Factor'});