%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Add noise to the data with a signal-to-noise ratio of 50 dB and enable the option for adding noise to the training dataset.

%% Code Writen by LLM:
[dataTrain, dataTest] = daline.data('case14', 300, 200, 'noise.SNR', 50, 'noise.addNoiseToTrain', true);