%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Filter out outliers from the training and testing datasets using the 'grubbs' method. Set the tolerance level for outlier detection as 0.7.

%% Code Writen by LLM:
opt = daline.setopt('num.trainSample', 400, 'num.testSample', 200, 'filOut.switchTrain', 1, 'filOut.switchTest', 1, 'filOut.method', 'grubbs', 'filOut.tol', 0.7);
data = daline.data('case.name', 'case14', opt);