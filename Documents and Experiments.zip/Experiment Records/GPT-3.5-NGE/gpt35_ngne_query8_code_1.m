%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples. Add outliers to the training data with a factor of 3 and an outlier percentage of 2.5%.

%% Code Writen by LLM:
opt = daline.setopt('case.name', 'case39', 'num.trainSample', 500, 'num.testSample', 250);
data = daline.generate(opt);

opt_outlier = daline.setopt('outlier.switchTrain', 1, 'outlier.factor', 3, 'outlier.percentage', 2.5);
data = daline.outlier(data, opt_outlier);

%% MATLAB:
% The above code ran successfully