function transMethod = func_get_transformedMethod
transMethod = {'LS_LIF', 'RR_VCS', 'SVR_POL'};