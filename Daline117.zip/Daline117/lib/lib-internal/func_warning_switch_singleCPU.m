function func_warning_switch_singleCPU(switch_indicator)
% Set warning off if requested
if switch_indicator 
    % Normal warning off
    warning off
end