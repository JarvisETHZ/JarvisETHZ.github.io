function func_check_optName_varargin(varargin)

