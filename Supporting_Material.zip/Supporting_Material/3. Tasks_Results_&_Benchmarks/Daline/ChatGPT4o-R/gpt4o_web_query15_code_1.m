%% Prompt:
% Generate data for 'case14' with 200 training samples and 150 testing samples.
% Train and test a model using RR_KPC, while set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'}.

%% Code Written by LLM:
% https://chatgpt.com/share/890f32be-13f8-439b-a358-98c9563adb3b
% Step 1: Set up options for data generation
opt_generate = daline.setopt('case.name', 'case14', 'num.trainSample', 200, 'num.testSample', 150, 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand');

% Step 2: Generate data
data = daline.generate(opt_generate);

% Step 3: Set up options for model training and testing using RR_KPC
opt_train_test = daline.setopt('method.name', 'RR_KPC', 'variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF', 'QF'});

% Step 4: Train and test the model
model = daline.fit(data, opt_train_test);

% Display the model
disp(model);

%% MATLAB:
% The above code ran successfully

%% Unnecessary settings
% 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand'