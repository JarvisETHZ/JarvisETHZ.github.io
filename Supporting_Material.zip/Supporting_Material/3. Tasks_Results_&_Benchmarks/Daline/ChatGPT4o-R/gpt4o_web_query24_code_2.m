
%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method LS_COD.
% Set the data base type to 'TimeSeriesRand' and the number of training samples to 300.
% Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/a10cdf58-143b-49e2-80b0-d1aa0db586fa
% Load MATPOWER case
mpc = loadcase('case118');

% Set data generation options
dataOptions.case.name = 'case118';
dataOptions.num.trainSample = 300;
dataOptions.data.baseType = 'TimeSeriesRand';
dataOptions.data.curvePlot = 0; % Disable plotting

% Generate data
[dataTrain, dataTest] = daline.generate(mpc, dataOptions);

% Set method options
methodOptions.method.name = 'LS_COD';
methodOptions.PLOT.switch = 0; % Disable plotting

% Fit the model using the specified method and options
model = daline.fit(dataTrain, methodOptions);

% Test the model
result = daline.test(model, dataTest);

% Display the model parameters and any relevant output
disp(model);
disp(result);
