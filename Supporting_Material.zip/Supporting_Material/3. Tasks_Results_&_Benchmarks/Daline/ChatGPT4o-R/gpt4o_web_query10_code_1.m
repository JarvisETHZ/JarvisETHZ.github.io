%% Prompt:
% Generate data for 'case57' with 600 training samples and 300 testing samples.
% Add noise to the training data with a SNR of 45dB. Then filter out noise from the training dataset.

%% Code Written by LLM:
% https://chatgpt.com/share/f6fb3e02-e930-4389-b058-df20e4eee88e
% Step 1: Set up the options for data generation
opt_gen = daline.setopt('case.name', 'case57', 'num.trainSample', 600, 'num.testSample', 300, 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand');

% Step 2: Generate the data
data = daline.generate(opt_gen);

% Step 3: Add noise to the training data with SNR of 45dB
opt_noise = daline.setopt('noise.switchTrain', 1, 'noise.SNR_dB', 45);
data = daline.noise(data, opt_noise);

% Step 4: Filter out the noise from the training data
opt_denoise = daline.setopt('filNoi.switchTrain', 1, 'filNoi.useARModel', false);
data = daline.denoise(data, opt_denoise);

% Display a message indicating that the process is complete
disp('Data generation, noise addition, and noise filtering are complete.');


%% MATLAB:
% The above code ran successfully

%% Unnecessary settings
% 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand'
% 'filNoi.useARModel', false