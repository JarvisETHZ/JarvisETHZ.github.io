%% Prompt:
% Please write the code to create data for 'case39' with 500 training samples and 300 testing samples, and add noise with a signal-to-noise ratio of 45 dB.

%% Code Writen by LLM:
data = daline.data('case.name', 'case39', 'num.trainSample', 500, 'num.testSample', 300, 'noise.switchTrain', 1, 'noise.SNR_dB', 45, 'noise.switchTest', 1);

%% MATLAB:
% The above code ran successfully