%% Prompt:
% Please write the code to generate training and testing data sets for 'case118' using the 'acpf' program and 'TimeSeriesRand' as the base type. Set the number of training samples to 300 and the number of testing samples to 200.

%% Code Writen by LLM:
% Set options for data generation
opt = daline.setopt('case.name', 'case118', 'num.trainSample', 300, 'num.testSample', 200, 'data.baseType', 'TimeSeriesRand', 'data.program', 'acpf');

% Generate data
data = daline.generate(opt);

%% MATLAB:
% The above code ran successfully