%% Prompt:
% Please write the code to prepare data for 'case118' with 500 training samples, 'TimeSeriesRand' base type, and enable parallel computation.

%% Code Writen by LLM:
% Set up the options for data generation
opt = daline.setopt('case.name', 'case118', 'num.trainSample', 500, 'data.baseType', 'TimeSeriesRand', 'parallel.enable', 1);

% Generate the data
data = daline.generate(opt);