%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Add noise to the data with a signal-to-noise ratio of 50 dB and enable the option for adding noise to the training dataset.

%% Code Writen by LLM:
% Generate data for 'case14'
data = daline.generate('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);

% Add noise to the training dataset with a signal-to-noise ratio of 50 dB
data = daline.noise(data, 'noise.switchTrain', 1, 'noise.SNR_dB', 50);

%% MATLAB:
% The above code ran successfully