%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Rank the accuracy of LS and QR Decomposition for 'case14'. Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods. Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously. Finally, disable the plotting. 

%% Code Writen by LLM:
% Generate data for 'case14' with 300 training samples and 200 testing samples
data = daline.generate('case14', 'samples.train', 300, 'samples.test', 200);

% Set the options for both methods simultaneously
opt = daline.setopt('variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF'}, 'plot.response', {'PF'}, 'plot.enable', false);

% Fit the model using Least Squares with Singular Value Decomposition (LS_SVD)
model_LS = daline.fit(data, 'method.name', 'LS_SVD', opt);

% Fit the model using Direct QR Decomposition (QR)
model_QR = daline.fit(data, 'method.name', 'QR', opt);

% Rank the accuracy of LS and QR Decomposition for 'case14'
accuracy_LS = daline.evaluate(model_LS, data);
accuracy_QR = daline.evaluate(model_QR, data);

% Display the accuracy results
disp('Accuracy of LS_SVD:');
disp(accuracy_LS);

disp('Accuracy of QR:');
disp(accuracy_QR);

% Rank the methods based on accuracy
if accuracy_LS > accuracy_QR
    disp('LS_SVD is more accurate than QR for case14.');
else
    disp('QR is more accurate than LS_SVD for case14.');
end