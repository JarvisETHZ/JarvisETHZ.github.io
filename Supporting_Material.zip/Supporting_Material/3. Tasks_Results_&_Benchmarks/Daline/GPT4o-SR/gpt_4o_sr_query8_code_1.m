%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples. Add outliers to the training data with a factor of 3 and an outlier percentage of 2.5%.

%% Code Writen by LLM:
% Generate data with specified number of training and testing samples
model = daline.all('case39', 'num.trainSample', 500, 'num.testSample', 250);

% Add outliers to the training data
model = daline.all('case39', 'num.trainSample', 500, 'num.testSample', 250, 'outlier.switchTrain', 1, 'outlier.percentage', 0.025, 'outlier.factor', 3);