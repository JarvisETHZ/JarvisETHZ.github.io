%% Prompt:
% Please write the code to generate data for 'case57' with the 'Random' base type, 300 training samples, and enable parallel computation.

%% Code Writen by LLM:
% Set options for data generation
opt = daline.setopt('case.name', 'case57', 'data.baseType', 'Random', 'num.trainSample', 300, 'data.parallel', 1);

% Generate data
data = daline.generate(opt);

%% MATLAB:
% The above code ran successfully