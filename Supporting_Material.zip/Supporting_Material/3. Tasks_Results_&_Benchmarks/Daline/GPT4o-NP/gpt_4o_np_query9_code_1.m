%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Add outliers to the training dataset with a percentage of 5%. 

%% Code Writen by LLM:
data = daline.data('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, 'outlier.switchTrain', 1, 'outlier.percentage', 5);

%% MATLAB:
% The above code ran successfully