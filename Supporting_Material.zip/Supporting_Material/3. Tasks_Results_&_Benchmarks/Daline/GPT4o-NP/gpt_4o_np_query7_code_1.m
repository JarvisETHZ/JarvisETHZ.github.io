%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Introduce outliers into the data with an outlier percentage of 5% and a factor of 2.

%% Code Writen by LLM:
data = daline.data('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200, 'outlier.switchTrain', 1, 'outlier.percentage', 5, 'outlier.factor', 2);

%% MATLAB:
% The above code ran successfully

%% Hidden Mistake:
% Missing parameters