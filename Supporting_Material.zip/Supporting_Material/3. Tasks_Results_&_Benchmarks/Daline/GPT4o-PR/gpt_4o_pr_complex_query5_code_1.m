%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Rank the accuracy of LS and QR Decomposition for 'case14'. Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods. Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously. Finally, disable the plotting. 

%% Code Writen by LLM:
% Step 1: Generate data for 'case14' with 300 training samples and 200 testing samples
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);
data = daline.data(opt);

% Step 2: Set the options for both LS and QR methods
opt = daline.setopt('variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF'}, 'PLOT.response', {'PF'}, 'PLOT.switch', 0);

% Step 3: Rank the accuracy of LS and QR Decomposition for 'case14'
[model, failedMethod] = daline.rank(data, {'LS', 'QR'}, opt);

%% MATLAB:
% The above code ran successfully