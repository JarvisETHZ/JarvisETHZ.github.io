%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Normalize both training and testing datasets. 

%% Code Writen by LLM:
% Generate data
data = daline.generate('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);

% Normalize data
data = daline.normalize(data);

%% MATLAB:
% The above code ran successfully