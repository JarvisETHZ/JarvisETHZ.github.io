%% Prompt:
% Generate data for 'case57' with 600 training samples and 300 testing samples. Add noise to the training data with a SNR of 45dB. Then Filter out noise from the training dataset.

%% Code Writen by LLM:
% Load the case57 system
mpc = loadcase('case57');

% Generate data
n_train = 600;
n_test = 300;
data = DataGen_case(mpc, 'n_train', n_train, 'n_test', n_test);

% Add noise to the training data with a SNR of 45dB
data_noisy = NoiseAdd_case(data, 'train', 'SNR', 45);

% Filter out noise from the training dataset
data_filtered = NoiseFilter_case(data_noisy, 'train');

% Save the generated data
save('case57_data.mat', 'data', 'data_noisy', 'data_filtered');