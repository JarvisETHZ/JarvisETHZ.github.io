%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Filter out outliers from the training dataset using the 'median' method and a tolerance of 5.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Generate data
data = generate_data('caseName', 'case14', 'n_train', 300, 'n_test', 200);

% Filter out outliers from the training dataset
filtered_data = filter_outliers(data, 'method', 'median', 'tol', 5);

% Save the filtered data
save('filtered_case14_data.mat', 'filtered_data');