%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Introduce outliers into the data with an outlier percentage of 5% and a factor of 2.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Set parameters for data generation
num_train_samples = 300;
num_test_samples = 200;
outlier_percentage = 5;
outlier_factor = 2;

% Generate training data
train_data = generateData('case14', num_train_samples);

% Generate testing data
test_data = generateData('case14', num_test_samples);

% Introduce outliers into the training data
train_data_with_outliers = introduceOutliers(train_data, outlier_percentage, outlier_factor);

% Introduce outliers into the testing data
test_data_with_outliers = introduceOutliers(test_data, outlier_percentage, outlier_factor);

% Save the generated data
save('case14_train_data.mat', 'train_data_with_outliers');
save('case14_test_data.mat', 'test_data_with_outliers');