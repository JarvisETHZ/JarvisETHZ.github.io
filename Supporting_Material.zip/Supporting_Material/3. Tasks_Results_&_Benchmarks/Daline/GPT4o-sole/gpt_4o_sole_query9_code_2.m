%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Add outliers to the training dataset with a percentage of 5%. 

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Set parameters for data generation
num_train_samples = 400;
num_test_samples = 200;
outlier_percentage = 5;

% Generate training data
train_data = generateData(mpc, 'numSamples', num_train_samples);

% Add outliers to the training data
train_data_with_outliers = addOutliers(train_data, 'percentage', outlier_percentage);

% Generate testing data
test_data = generateData(mpc, 'numSamples', num_test_samples);

% Save the generated data
save('case14_train_data.mat', 'train_data_with_outliers');
save('case14_test_data.mat', 'test_data');