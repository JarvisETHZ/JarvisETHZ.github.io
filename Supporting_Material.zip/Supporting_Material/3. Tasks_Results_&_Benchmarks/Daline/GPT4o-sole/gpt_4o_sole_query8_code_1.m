%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples. Add outliers to the training data with a factor of 3 and an outlier percentage of 2.5%.

%% Code Writen by LLM:
% Load the case39 data
mpc = loadcase('case39');

% Set parameters for data generation
num_train_samples = 500;
num_test_samples = 250;
outlier_factor = 3;
outlier_percentage = 2.5;

% Generate training data with outliers
train_data = generate_data(mpc, num_train_samples, 'outlier_factor', outlier_factor, 'outlier_percentage', outlier_percentage);

% Generate testing data without outliers
test_data = generate_data(mpc, num_test_samples);

% Save the generated data
save('case39_train_data.mat', 'train_data');
save('case39_test_data.mat', 'test_data');