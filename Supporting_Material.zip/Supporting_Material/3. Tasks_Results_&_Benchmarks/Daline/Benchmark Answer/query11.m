%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples. Filter out outliers from the data using the 'quartiles' method with a tolerance of 5 and enable the filtering for the training dataset.

%% Code Writen by LLM:
data = daline.data('case.name', 'case39', 'num.trainSample', 500, 'num.testSample', 250, 'filOut.method', 'quartiles', 'filOut.tol', 5, 'filOut.switchTrain', 1);

%% MATLAB:
% The above code ran successfully

%% Note:
% with 'outlier.switchTrain', 1, is also okay, as it makes more sense: adding outliers first before filtering it. More importantly: adding outliers to the training dataset => not random