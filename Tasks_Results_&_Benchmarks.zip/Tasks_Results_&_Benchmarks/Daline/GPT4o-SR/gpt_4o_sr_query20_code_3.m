%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Generate data for 'case14' with 400 training samples and 200 testing samples
data = daline.data('case14', 'num.trainSample', 400, 'num.testSample', 200);

% Fit the Decoupled Linearized Power Flow with Data-driven Correction (DLPF_C) model
model_DLPF_C = daline.fit(data, 'method.name', 'DLPF_C');

% Fit the Power Transfer Distribution Factor (PTDF) model
model_PTDF = daline.fit(data, 'method.name', 'PTDF');

% Evaluate the accuracy of the DLPF_C model
accuracy_DLPF_C = daline.evaluate(model_DLPF_C, data);

% Evaluate the accuracy of the PTDF model
accuracy_PTDF = daline.evaluate(model_PTDF, data);

% Display the accuracy results
disp('Accuracy of DLPF_C:');
disp(accuracy_DLPF_C);

disp('Accuracy of PTDF:');
disp(accuracy_PTDF);