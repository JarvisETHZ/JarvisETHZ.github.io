%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Rank the accuracy of LS and QR Decomposition for 'case14'. Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods. Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously. Finally, disable the plotting. 

%% Code Writen by LLM:
% Generate data for 'case14' with 300 training samples and 200 testing samples
data = daline.generate('case.name', 'case14', 'samples.train', 300, 'samples.test', 200);

% Set the options for both methods simultaneously
opt = daline.setopt('variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF'}, 'plot.response', {'PF'}, 'plot.enable', false);

% Define the methods to be ranked
methods = {'LS', 'QR'};

% Rank the accuracy of LS and QR Decomposition for 'case14'
[model, failedMethod] = daline.rank(data, methods, opt);

% Display the ranking results
disp('Ranking results:');
disp(model);
disp('Failed methods:');
disp(failedMethod);