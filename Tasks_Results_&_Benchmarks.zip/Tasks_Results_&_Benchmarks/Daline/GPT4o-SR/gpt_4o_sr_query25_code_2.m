%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method PLS_CLS. Set the data base type to 'TimeSeriesRand' and the method's cross-validation folds to 5. Disable the plotting.

%% Code Writen by LLM:
% Set options for data generation
opt_data = daline.setopt('case.name', 'case118', 'data.baseType', 'TimeSeriesRand', 'num.trainSample', 500, 'num.testSample', 300);

% Generate data
data = daline.generate(opt_data);

% Set options for the PLS_CLS method
opt_method = daline.setopt('method.name', 'PLS_CLS', 'PLS.cvNumFold', 5, 'PLOT.switch', 0);

% Fit the model
model = daline.fit(data, opt_method);

% Optionally, you can also run the complete cycle using daline.all
[model, data, failure] = daline.all('case118', 'method.name', 'PLS_CLS', 'PLS.cvNumFold', 5, 'PLOT.switch', 0);