%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Filter out outliers from the training dataset using the 'median' method and a tolerance of 5.

%% Code Writen by LLM:
% Generate data
data = daline.generate('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);

% Add outliers to the training data
data = daline.outlier(data, 'outlier.switchTrain', 1, 'outlier.factor', 2, 'outlier.percentage', 0.5);

% Filter out outliers from the training data using the 'median' method and a tolerance of 5
data = daline.deoutlier(data, 'filOut.switchTrain', 1, 'filOut.method', 'median', 'filOut.tol', 5);

%% MATLAB:
% The above code ran successfully

%% Unnecessary
% 'outlier.factor', 2, 'outlier.percentage', 0.5