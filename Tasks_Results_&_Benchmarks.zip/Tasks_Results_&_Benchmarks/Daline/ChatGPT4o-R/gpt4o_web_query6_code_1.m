%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples.
% Add noise to the data with a signal-to-noise ratio of 50 dB and enable the option for adding noise to the training dataset.

%% Code Written by LLM:
% https://chatgpt.com/share/cf690cdf-7310-4306-83ac-21316a4020cb
% Setting up the options for data generation
opt = daline.setopt(...
    'case.name', 'case14', ...               % Specify the case name
    'num.trainSample', 300, ...              % Number of training samples
    'num.testSample', 200, ...               % Number of testing samples
    'data.program', 'acpf', ...              % Use AC power flow for data generation
    'data.baseType', 'TimeSeriesRand', ...   % Data type with time series and randomness
    'noise.switchTrain', 1, ...              % Enable noise for training data
    'noise.SNR_dB', 50);                     % Signal-to-noise ratio in dB

% Generating the data with the specified options
data = daline.generate(opt);

% Adding noise to the data with the specified SNR
data = daline.noise(data, 'noise.switchTrain', 1, 'noise.SNR_dB', 50);

%% MATLAB:
% The above code ran successfully

%% Hidden Mistake:
% Parameters 'noise.switchTrain' and 'noise.SNR_dB' do not apply to daline.generate()