%% Prompt:
% Generate data for 'case39' with 500 training samples and 200 testing samples.
% Compare and rank the accuracy of the following methods: PLS_REC, DC, the direct principal component analysis, PLS_SIM, and LS_PCA.
% Set the new data percentage for the method PLS_REC as 30%.
% Use parallel computation for method LS_PCA.
% Set the ratio of principal components for LS_PCA as 40%.
% Set the plot response as {'Vm'} for all methods.
% Finally, set the plotting type as 'moment', and the plotting theme as 'commercial'.
% Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/ae52a235-a174-44e1-8910-416b6686950e
% Generate data for 'case39'
opt = daline.setopt('case.name', 'case39', 'num.trainSample', 500, 'num.testSample', 200, ...
                    'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'data.parallel', 1);

data = daline.data(opt);

% Set options for the methods
opt_PLS_REC = daline.setopt('method.name', 'PLS_REC', 'PLS.recursivePercentage', 30, 'variable.response', {'Vm'});
opt_DC = daline.setopt('method.name', 'DC', 'variable.response', {'Vm'});
opt_PCA = daline.setopt('method.name', 'directPCA', 'variable.response', {'Vm'});
opt_PLS_SIM = daline.setopt('method.name', 'PLS_SIM', 'variable.response', {'Vm'});
opt_LS_PCA = daline.setopt('method.name', 'LS_PCA', 'LS.PCA.principalComponentRatio', 0.4, 'LS.parallel', 1, 'variable.response', {'Vm'});

% Combine options into one structure
methods = {'PLS_REC', 'DC', 'directPCA', 'PLS_SIM', 'LS_PCA'};
opt_global = daline.setopt('variable.response', {'Vm'}, 'PLOT.response', {'Vm'}, ...
                           'PLOT.type', 'moment', 'PLOT.theme', 'commercial', 'PLOT.enable', 0);

% Rank the methods
[model, failedMethod] = daline.rank(data, methods, opt_global);

% Display the ranking results
disp('Ranking of the methods based on accuracy:');
disp(model);
disp('Failed methods:');
disp(failedMethod);
