%% Prompt:
% Please write the code to generate data for 'case57' with the 'Random' base type, 300 training samples, and enable parallel computation.

%% Code Written by LLM:
% https://chatgpt.com/share/110405d7-c23f-4e4a-808d-c0eb67ad6988
% Set up the options using daline.setopt
opt = daline.setopt('case.name', 'case57', ... % Specify the case name
                    'data.baseType', 'Random', ... % Set the base type to Random
                    'num.trainSample', 300, ... % Number of training samples
                    'data.parallel', 1); % Enable parallel computation

% Generate the data using daline.generate with the specified options
data = daline.generate(opt);

%% MATLAB:
% The above code ran successfully