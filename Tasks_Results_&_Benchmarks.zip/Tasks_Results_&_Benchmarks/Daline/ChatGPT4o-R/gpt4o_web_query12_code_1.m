%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. 
% Filter out outliers from the training dataset using the 'median' method and a tolerance of 5.

%% Code Written by LLM:
% https://chatgpt.com/share/e377c044-8bfc-45cc-b6c8-ec17a7ae8212
% Set options for data generation
opt = daline.setopt('case.name', 'case14', ...
                    'num.trainSample', 300, ...
                    'num.testSample', 200, ...
                    'data.program', 'acpf', ...
                    'data.baseType', 'TimeSeriesRand');

% Generate data
data = daline.generate(opt);

% Set options for filtering outliers
filter_opt = daline.setopt('filOut.switchTrain', 1, ...
                           'filOut.method', 'median', ...
                           'filOut.tol', 5);

% Filter out outliers from the training data
data = daline.deoutlier(data, filter_opt);

%% MATLAB:
% The above code ran successfully

%% Unnecessary settings
% 'data.program', 'acpf', ...
% 'data.baseType', 'TimeSeriesRand'
