%% Prompt:
% Generate data for 'case9' with 200 training samples and 150 testing samples, 
% use the type 'TimeSeriesRand' for data generation, 
% turn on the noise adding mode for the training dataset,
% add noise to the training dataset with a signal-to-noise ratio of 45 dB.
% Compare and rank the computing efficiency of methods LS_LIFX and RR_KPC.
% Set the number of clusters as 3 for RR_KPC.
% Use 5 repetitions for plotting.
% Use the dark style for plotting, but disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/4e36a653-ebf3-4f96-accb-6a4d59a69361
% Step 1: Set the options for data generation
opt = daline.setopt(...
    'case.name', 'case9', ...
    'num.trainSample', 200, ...
    'num.testSample', 150, ...
    'data.baseType', 'TimeSeriesRand', ...
    'noise.switchTrain', 1, ...
    'noise.SNR_dB', 45, ...
    'PLOT.switch', 0, ... % Disable plotting
    'PLOT.theme', 'dark', ...
    'RR.clusNumInterval', 3, ...
    'variable.liftType', 'random', ... % Needed for LS_LIFX method
    'num.repetition', 5 ... % Repetitions for ranking
);

% Step 2: Generate data
data = daline.generate(opt);

% Step 3: Set the methods for comparison
methods = {'LS_LIFX', 'RR_KPC'};

% Step 4: Rank the methods based on computing efficiency
[model, failedMethod] = daline.rank(data, methods, opt);

% Display the results
disp('Ranking of methods based on computing efficiency:');
disp(model);
disp('Methods that failed:');
disp(failedMethod);
