%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Load the case14 data
mpc = loadcase('case14');

% Generate data
generateData(mpc, 'train', 300, 'test', 200);

% Perform linearization using Least Squares with Huber Weighting Function
linearizePF(mpc, 'method', 'LS', 'LS.weighting', 'Huber');

% Visualize the linearization results with specified styles and themes
visualizeLinearization(mpc, 'style', 'dark', 'theme', 'academic', 'plotting', false);