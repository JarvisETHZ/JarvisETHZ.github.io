%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Filter out outliers from the training and testing datasets using the 'grubbs' method. Set the tolerance level for outlier detection as 0.7.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Generate data
n_train = 400;
n_test = 200;
data = generate_data(mpc, n_train, n_test);

% Filter out outliers using the 'grubbs' method with a tolerance level of 0.7
data_filtered = filter_outliers(data, 'method', 'grubbs', 'tol', 0.7);

% Extract the filtered training and testing datasets
train_data = data_filtered.train;
test_data = data_filtered.test;