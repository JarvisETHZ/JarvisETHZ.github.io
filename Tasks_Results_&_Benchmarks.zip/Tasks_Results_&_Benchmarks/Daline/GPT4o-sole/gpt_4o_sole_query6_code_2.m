%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Add noise to the data with a signal-to-noise ratio of 50 dB and enable the option for adding noise to the training dataset.

%% Code Writen by LLM:
% Load the Daline toolbox
addpath('path_to_daline_toolbox');

% Define the parameters for data generation
caseName = 'case14';
nTrain = 300;
nTest = 200;
SNR = 50;
addNoise2Train = true;

% Generate the data
[data_train, data_test] = generateData(caseName, nTrain, nTest, SNR, addNoise2Train);

% Save the generated data
save('data_train.mat', 'data_train');
save('data_test.mat', 'data_test');