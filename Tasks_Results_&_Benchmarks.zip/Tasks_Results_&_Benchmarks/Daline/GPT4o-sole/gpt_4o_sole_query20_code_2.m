%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Set parameters for data generation
num_train = 400;
num_test = 200;

% Generate training data
train_data = generateData(mpc, num_train);

% Generate testing data
test_data = generateData(mpc, num_test);

% Define the models to compare
models = {'DLPF_DC', 'PTDF'};

% Initialize accuracy storage
accuracy = struct();

% Loop over each model and compute accuracy
for i = 1:length(models)
    model = models{i};
    
    % Train the model
    trained_model = trainModel(train_data, model);
    
    % Test the model
    accuracy.(model) = testModel(test_data, trained_model);
end

% Display the accuracy results
disp('Accuracy of Decoupled Linearized Power Flow with Data-driven Correction:');
disp(accuracy.DLPF_DC);

disp('Accuracy of Power Transfer Distribution Factor:');
disp(accuracy.PTDF);

% Helper functions
function data = generateData(mpc, num_samples)
    % Generate data for the given case and number of samples
    data = generate_data(mpc, num_samples, 'method', 'uniform', 'perturbation', 0.1);
end

function model = trainModel(data, model_name)
    % Train the specified model using the provided data
    model = train_model(data, 'method', model_name);
end

function accuracy = testModel(data, model)
    % Test the model and return the accuracy
    results = test_model(data, model);
    accuracy = results.accuracy;
end