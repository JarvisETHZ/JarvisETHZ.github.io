%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Visualize the linearization results of Partial Least Squares with Clustering with a light style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Generate data
data = generate_data(mpc, 'train', 400, 'test', 200);

% Perform Partial Least Squares with Clustering linearization
results = linearize(data, 'method', 'PLS', 'PLS.clustering', true);

% Visualize the linearization results
visualize(results, 'style', 'light', 'theme', 'academic', 'plotting', false);