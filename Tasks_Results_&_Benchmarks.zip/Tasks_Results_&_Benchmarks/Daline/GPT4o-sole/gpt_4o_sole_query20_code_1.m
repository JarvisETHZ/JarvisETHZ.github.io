%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Set parameters for data generation
num_train = 400;
num_test = 200;

% Generate training data
train_data = generate_data(mpc, num_train);

% Generate testing data
test_data = generate_data(mpc, num_test);

% Define the models to compare
models = {'DLPF_DC', 'PTDF'};

% Initialize accuracy storage
accuracy = struct();

% Loop over each model and compute accuracy
for i = 1:length(models)
    model = models{i};
    
    % Train the model
    trained_model = train_model(train_data, model);
    
    % Test the model
    accuracy.(model) = test_model(test_data, trained_model);
end

% Display the accuracy results
disp('Accuracy of Decoupled Linearized Power Flow with Data-driven Correction:');
disp(accuracy.DLPF_DC);

disp('Accuracy of Power Transfer Distribution Factor:');
disp(accuracy.PTDF);