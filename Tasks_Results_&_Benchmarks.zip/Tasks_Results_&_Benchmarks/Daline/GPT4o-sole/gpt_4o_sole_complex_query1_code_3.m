%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare and rank the accuracy of the ordinary least squares, and the ordinary ridge regression for 'case14'. Set the regularization factor as 1e-10 for the ordinary ridge regression. Set the plotting responses to {'P', 'Vm2'} for all methods. Finally, use the dark style for plotting the ranking, and set the type of plotting as 'probability'. Disable the plotting. 

%% Code Writen by LLM:
% Load the case14 data
mpc = loadcase('case14');

% Generate data
data = generate_data(mpc, 'n_train', 400, 'n_test', 200);

% Define methods to compare
methods = {'OLS', 'RR'};

% Set parameters for ridge regression
RR.lambda = 1e-10;

% Set plotting responses
plot_responses = {'P', 'Vm2'};

% Perform comparison and ranking
results = compare_methods(data, methods, 'RR.lambda', RR.lambda, ...
                          'plot.responses', plot_responses, ...
                          'plot.style', 'dark', 'plot.type', 'probability', ...
                          'plotting', false);

% Display results
disp(results);