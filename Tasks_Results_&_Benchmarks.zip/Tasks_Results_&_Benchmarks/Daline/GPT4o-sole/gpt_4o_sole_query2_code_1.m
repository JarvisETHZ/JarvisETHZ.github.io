%% Prompt:
% Please write the code to create data for 'case39' with 500 training samples and 300 testing samples, and add noise with a signal-to-noise ratio of 45 dB.

%% Code Writen by LLM:
% Load the case data
mpc = loadcase('case39');

% Set parameters for data generation
num_train_samples = 500;
num_test_samples = 300;
snr = 45; % Signal-to-noise ratio in dB

% Generate training data
train_data = generate_data(mpc, num_train_samples, 'train', 'snr', snr);

% Generate testing data
test_data = generate_data(mpc, num_test_samples, 'test', 'snr', snr);

% Save the generated data
save('case39_train_data.mat', 'train_data');
save('case39_test_data.mat', 'test_data');