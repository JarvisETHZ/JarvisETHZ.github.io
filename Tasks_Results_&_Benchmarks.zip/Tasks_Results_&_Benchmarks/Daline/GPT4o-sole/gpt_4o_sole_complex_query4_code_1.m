%% Prompt:
% Generate data for 'case118' with 600 training samples and 300 testing samples. Compare and rank the accuracy of LS_COD and RR_VCS for 'case118'. Set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'} for both methods. Set the lambda interval for Ordinary Ridge Regression with the Voltage-angle Coupling to 1e-7. Finally, set the plotting theme as 'academic', but disable the plotting. 

%% Code Writen by LLM:
% Load the case
mpc = loadcase('case118');

% Generate data
data = generate_data(mpc, 'train', 600, 'test', 300);

% Set predictors and responses
predictors = {'P', 'Vm2'};
responses = {'PF', 'QF'};

% Set lambda interval for RR_VCS
lambda_interval = 1e-7;

% Perform LS_COD
results_LS_COD = LS_COD(data, 'predictors', predictors, 'responses', responses);

% Perform RR_VCS
results_RR_VCS = RR_VCS(data, 'predictors', predictors, 'responses', responses, 'lambda_interval', lambda_interval);

% Compare and rank accuracy
comparison_results = compare_methods(data, 'methods', {'LS_COD', 'RR_VCS'}, 'predictors', predictors, 'responses', responses);

% Set plotting theme and disable plotting
set_plotting('theme', 'academic', 'plot', false);

% Display comparison results
disp(comparison_results);