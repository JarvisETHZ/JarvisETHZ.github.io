%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Normalize both training and testing datasets. 

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Set the number of samples
num_train_samples = 300;
num_test_samples = 200;

% Generate training data
train_data = generateData(mpc, num_train_samples);

% Generate testing data
test_data = generateData(mpc, num_test_samples);

% Normalize the training data
[train_data_normalized, train_mu, train_sigma] = normalizeData(train_data);

% Normalize the testing data using the training data statistics
test_data_normalized = normalizeData(test_data, train_mu, train_sigma);

% Save the generated data
save('case14_train_data.mat', 'train_data_normalized', 'train_mu', 'train_sigma');
save('case14_test_data.mat', 'test_data_normalized');