%% Prompt:
% Please write the code to create data for 'case39' with 500 training samples and 300 testing samples, and add noise with a signal-to-noise ratio of 45 dB.

%% Code Writen by LLM:
% Load the case data
mpc = loadcase('case39');

% Set parameters for data generation
num_train_samples = 500;
num_test_samples = 300;
snr = 45; % Signal-to-noise ratio in dB

% Generate training data
train_data = generateData('caseName', 'case39', 'numSamples', num_train_samples, 'dataType', 'train', 'snr', snr);

% Generate testing data
test_data = generateData('caseName', 'case39', 'numSamples', num_test_samples, 'dataType', 'test', 'snr', snr);

% Save the generated data
save('case39_train_data.mat', 'train_data');
save('case39_test_data.mat', 'test_data');