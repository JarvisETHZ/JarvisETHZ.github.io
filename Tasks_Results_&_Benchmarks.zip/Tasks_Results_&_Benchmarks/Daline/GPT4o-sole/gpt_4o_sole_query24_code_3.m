%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method LS_COD. Set the data base type to 'TimeSeriesRand' and the number of training samples to 300. Disable the plotting.

%% Code Writen by LLM:
% Load the case
mpc = loadcase('case118');

% Set the parameters for the data base
dataBaseType = 'TimeSeriesRand';
numTrainSamples = 300;

% Generate the data base
dataBase = generate_DB(mpc, 'type', dataBaseType, 'numSamples', numTrainSamples);

% Set the method to LS_COD
method = 'LS_COD';

% Disable plotting
plotting = false;

% Perform the linearization
results = linearize_PF(mpc, dataBase, 'method', method, 'plotting', plotting);

% Display the results
disp(results);