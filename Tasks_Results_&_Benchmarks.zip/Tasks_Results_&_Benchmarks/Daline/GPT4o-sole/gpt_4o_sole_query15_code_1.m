%% Prompt:
% Generate data for 'case14' with 200 training samples and 150 testing samples. Train and test a model using RR_KPC, while set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'}.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Generate data
data = generate_data(mpc, 'train', 200, 'test', 150);

% Set predictors and responses
predictors = {'P', 'Vm2'};
responses = {'PF', 'QF'};

% Train the model using RR_KPC
model = train(data, 'method', 'RR_KPC', 'predictors', predictors, 'responses', responses);

% Test the model
results = test(model, data);

% Display the results
disp(results);