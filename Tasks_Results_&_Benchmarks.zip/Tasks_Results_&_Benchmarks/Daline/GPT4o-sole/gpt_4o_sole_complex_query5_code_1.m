%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Rank the accuracy of LS and QR Decomposition for 'case14'. Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods. Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously. Finally, disable the plotting. 

%% Code Writen by LLM:
% Generate data for 'case14' with 300 training samples and 200 testing samples
data = generate_data('case14', 'train', 300, 'test', 200);

% Define the variable predictors and responses
predictors = {'P', 'Vm2'};
responses = {'PF'};

% Set the plotting response
plot_response = {'PF'};

% Disable plotting
plotting = false;

% Rank the accuracy of LS and QR Decomposition for 'case14'
results = rank_accuracy(data, 'methods', {'LS', 'QR'}, ...
                        'predictors', predictors, ...
                        'responses', responses, ...
                        'plot_response', plot_response, ...
                        'plotting', plotting);

% Display the results
disp(results);