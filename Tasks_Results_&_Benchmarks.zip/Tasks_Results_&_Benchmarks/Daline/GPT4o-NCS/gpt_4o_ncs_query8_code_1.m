%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples. Add outliers to the training data with a factor of 3 and an outlier percentage of 2.5%.

%% Code Writen by LLM:
% Generate data
data = daline.generate('case.name', 'case39', 'num.trainSample', 500, 'num.testSample', 250);

% Add outliers to the training data
data = daline.outlier(data, 'outlier.switchTrain', 1, 'outlier.factor', 3, 'outlier.percentage', 2.5);

%% MATLAB:
% The above code ran successfully