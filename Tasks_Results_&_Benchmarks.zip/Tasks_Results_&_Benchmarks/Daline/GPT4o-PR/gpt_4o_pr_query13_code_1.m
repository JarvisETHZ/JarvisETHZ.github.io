%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Filter out outliers from the training and testing datasets using the 'grubbs' method. Set the tolerance level for outlier detection as 0.7.

%% Code Writen by LLM:
% Generate data
data = daline.generate('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);

% Filter outliers from training data
data = daline.deoutlier(data, 'filOut.switchTrain', 1, 'filOut.method', 'grubbs', 'filOut.tol', 0.7);

% Filter outliers from testing data
data = daline.deoutlier(data, 'filOut.switchTest', 1, 'filOut.method', 'grubbs', 'filOut.tol', 0.7);

%% MATLAB:
% The above code ran successfully