%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Rank the accuracy of LS and QR Decomposition for 'case14'. Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods. Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously. Finally, disable the plotting. 

%% Code Writen by LLM:
data = daline.data('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);
ranking = daline.rank(data, {'LS', 'QR'}, 'variable.predictor', {'P', 'Vm2'}, 'variable.response', {'PF'}, 'PLOT.response', {'PF'}, 'PLOT.switch', 0);

%% MATLAB:
% The above code ran successfully