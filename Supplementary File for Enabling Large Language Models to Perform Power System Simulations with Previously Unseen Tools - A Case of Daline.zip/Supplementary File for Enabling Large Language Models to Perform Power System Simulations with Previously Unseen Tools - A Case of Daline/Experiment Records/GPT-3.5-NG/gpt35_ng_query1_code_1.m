%% Prompt:
% Please write the code to generate training and testing data sets for 'case118' using the 'acpf' program and 'TimeSeriesRand' as the base type. Set the number of training samples to 300 and the number of testing samples to 200.

%% Code Writen by LLM:
data = daline.data('case.name', 'case118', 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'num.trainSample', 300, 'num.testSample', 200);

%% MATLAB:
% The above code ran successfully