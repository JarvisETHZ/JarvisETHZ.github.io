%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Filter out outliers from the training and testing datasets using the 'grubbs' method. Set the tolerance level for outlier detection as 0.7.

%% Code Writen by LLM:
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, ...
    'outlier.switchTrain', 1, 'outlier.switchTest', 1, 'outlier.method', 'grubbs', 'outlier.tol', 0.7);

data = daline.data(opt);