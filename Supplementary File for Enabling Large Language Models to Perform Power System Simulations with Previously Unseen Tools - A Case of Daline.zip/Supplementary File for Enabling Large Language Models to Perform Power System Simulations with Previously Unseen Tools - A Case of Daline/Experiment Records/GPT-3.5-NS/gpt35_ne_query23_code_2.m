%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Visualize the linearization results of Partial Least Squares with Clustering with a light style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);
data = daline.generate(opt);

opt_plot = daline.setopt('PLOT.style', 'light', 'PLOT.theme', 'academic', 'PLOT.enable', 0);
model = daline.fit(data, 'method.name', 'PLS_CLS');
daline.plot(model, opt_plot);