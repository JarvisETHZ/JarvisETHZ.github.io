%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Add outliers to the training dataset with a percentage of 5%. 

%% Code Writen by LLM:
options = struct('outlierPercentage', 5);
[dataTrain, dataTest] = daline.data('case14', 400, 200, options);