%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method LS_COD. Set the data base type to 'TimeSeriesRand' and the number of training samples to 300. Disable the plotting.

%% Code Writen by LLM:
options.plot = false;
[data_train, data_test, model] = daline.all('case118', 'LS_COD', 'TimeSeriesRand', 300, options);