%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Normalize both training and testing datasets. 

%% Code Writen by LLM:
[dataTrain, dataTest] = daline.data('case14', 300, 200, 'normalize', true);