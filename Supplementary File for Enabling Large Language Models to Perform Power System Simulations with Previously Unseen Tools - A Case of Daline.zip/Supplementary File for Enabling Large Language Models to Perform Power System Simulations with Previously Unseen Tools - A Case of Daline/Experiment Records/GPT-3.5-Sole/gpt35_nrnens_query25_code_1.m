%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method PLS_CLS. Set the data base type to 'TimeSeriesRand' and the method's cross-validation folds to 5. Disable the plotting.

%% Code Writen by LLM:
daline.all('case118', 'PLS_CLS', 'dataBaseType', 'TimeSeriesRand', 'PLS.cvNumFold', 5, 'plot', false);