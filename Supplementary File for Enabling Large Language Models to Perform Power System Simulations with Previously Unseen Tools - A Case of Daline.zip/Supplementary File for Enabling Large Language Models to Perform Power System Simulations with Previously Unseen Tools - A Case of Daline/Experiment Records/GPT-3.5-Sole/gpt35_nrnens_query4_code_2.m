%% Prompt:
% Please write the code to generate data for 'case57' with the 'Random' base type, 300 training samples, and enable parallel computation.

%% Code Writen by LLM:
data = daline.generate('case57', 'Random', 300, 'parallel', true);