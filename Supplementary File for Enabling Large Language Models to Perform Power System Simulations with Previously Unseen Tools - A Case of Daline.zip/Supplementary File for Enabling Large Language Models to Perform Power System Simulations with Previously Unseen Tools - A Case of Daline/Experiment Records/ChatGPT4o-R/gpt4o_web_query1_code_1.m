%% Prompt:
% Please write the code to generate training and testing data sets for 'case118' using 
% the 'acpf' program and 'TimeSeriesRand' as the base type. Set the number of training
% samples to 300 and the number of testing samples to 200.

%% Code Written by LLM:
% https://chatgpt.com/share/f3666ce5-9a21-4854-a525-0e902085631e
% Generate training and testing datasets for 'case118' using 'acpf' program and 'TimeSeriesRand'
% base type with 300 training samples and 200 testing samples.

% Create options structure with specified parameters
opt = daline.setopt('case.name', 'case118', ...
                    'num.trainSample', 300, ...
                    'num.testSample', 200, ...
                    'data.program', 'acpf', ...
                    'data.baseType', 'TimeSeriesRand');

% Generate the data
data = daline.generate(opt);

%% MATLAB:
% The above code ran successfully