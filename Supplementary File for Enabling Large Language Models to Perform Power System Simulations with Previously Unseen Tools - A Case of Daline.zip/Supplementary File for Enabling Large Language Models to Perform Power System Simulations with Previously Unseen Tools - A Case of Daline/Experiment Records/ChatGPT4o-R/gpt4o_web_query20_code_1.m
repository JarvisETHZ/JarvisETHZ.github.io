%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples.
% Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and 
% Power Transfer Distribution Factor for 'case14'.

%% Code Written by LLM:
% https://chatgpt.com/share/b1ad765f-5520-4643-a7be-776c5119217d
% Step 1: Data Generation
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, ...
                    'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand');
data = daline.generate(opt);

% Step 2: Apply DLPF_C method for linearization
opt_DLPF_C = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, ...
                           'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'method.name', 'DLPF_C');
model_DLPF_C = daline.fit(data, opt_DLPF_C);

% Step 3: Apply PTDF method for linearization
opt_PTDF = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, ...
                         'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'method.name', 'PTDF');
model_PTDF = daline.fit(data, opt_PTDF);

% Step 4: Evaluate accuracy of both models
accuracy_DLPF_C = daline.evaluate(model_DLPF_C, data);
accuracy_PTDF = daline.evaluate(model_PTDF, data);

% Display the results
fprintf('Accuracy of Decoupled Linearized Power Flow with Data-driven Correction (DLPF_C): %f\n', accuracy_DLPF_C);
fprintf('Accuracy of Power Transfer Distribution Factor (PTDF): %f\n', accuracy_PTDF);
