%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Filter out outliers from the training dataset using the 'median' method and a tolerance of 5.

%% Code Writen by LLM:
data = daline.generate('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);
data = daline.deoutlier(data, 'filOut.switchTrain', 1, 'filOut.method', 'median', 'filOut.tol', 5);

%% MATLAB:
% The above code ran successfully